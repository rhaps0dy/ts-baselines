function [ R ] = CFS( Feature,Label,K )
%CFS Summary of this function goes here
%   Detailed explanation goes here
R = [];     % Initialize the output
[Data_No,Feature_No] = size(Feature);   % Input parameter

%% Algorithm
% Iterated the entire algorithm for K times
for i = 1:K
    % The first discovered R feature
    if (i == 1)    
        % Corr of each feature with label
        for j = 1:Feature_No
            Temp = corrcoef(Feature(:,j),Label);
            Tempo(j) = abs(Temp(1,2));
        end
        % Maximum Corr feature discover
        [A, Temp_idx] = max(Tempo);
        
        % Tie Breaker
        pos = randi(length(Temp_idx));
        idx = Temp_idx(pos);
        R = [R,idx];
    
    % From the second feature to K-th feature
    else
        % Denominator
        for j = 1:Feature_No
            % Only for the features exclude R
            if (ismember(j,R)==0)
                % Corr between two features jointly
                Temp = corrcoef(Feature(:,[R,j]));
                Temp = abs(Temp);
                Denom(j) = ( sum(sum(Temp)) - (length(R)+1) )/2;
            % Otherwise, big Denom assign
            else
                Denom(j) = 10000;
            end
        end
        
        % Nominator
        Tempor = 0;     
        % Sum of the correlation between Label and Features in R
        for k = 1:length(R)
            Temp = corrcoef(Feature(:,R(k)),Label);
            Tempo = abs(Temp(1,2));
            Tempor = Tempor + Tempo;
        end
                
        % Nominator of each feature
        for j = 1:Feature_No
            % For the features outside of the R
            if (ismember(j,R)==0)
                Temp = corrcoef(Feature(:,j),Label);
                Tempo = abs(Temp(1,2));
                Nom(j) = Tempor + Tempo;
            % Otherwise
            else
                Nom(j) = 0.00001;
            end
        end
        
        % Compute the merit function
        for j = 1:Feature_No
            Val(j) = Nom(j)/sqrt(length(R)+1 + 2*Denom(j));
        end
        % Feature with maximum merit function
        [A, Temp_idx] = max(Val);
        % Tie Breaker
        pos = randi(length(Temp_idx));
        idx = Temp_idx(pos);
        R = [R,idx];
    end
end
        

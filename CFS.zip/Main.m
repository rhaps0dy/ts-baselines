clear;

%% Data
%% 1. Data Input
load('Data.mat');
% Input_Feature, Input_Label

K = 10;
R = CFS(Feature,Label,K);

